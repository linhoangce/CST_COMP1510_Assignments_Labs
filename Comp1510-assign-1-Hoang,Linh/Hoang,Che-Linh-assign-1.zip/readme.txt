[Student Name], [Student ID], [Set], [Date]
Che Linh Hoang, A01401943, Set C, 02/12/2024

This assignment is 100% complete.


------------------------
Question one (Change) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question two (Sqrt) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question three (Reverse) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question four (Pack) status:

Complete
[explanation if not complete, what is working/not working]
