module FirstModularProject_Lab04 {
    requires org.junit.jupiter.api;
    requires org.junit.platform.runner;
    requires org.junit.jupiter.params;
}